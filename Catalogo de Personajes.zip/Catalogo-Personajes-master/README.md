# Catalogo-Personajes
El siguiente programa busca el uso del patron Abstract Factory, consiste en la creacion de familias de objetos especializadas para la batalla entre especies.
Ejemplo la creacion de la arma, escudo y caballeria para un orco.
